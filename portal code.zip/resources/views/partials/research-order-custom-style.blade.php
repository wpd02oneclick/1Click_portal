<style>
    .msg_card_body {
        background: url({{ asset('assets/images/pattern2.png')}}) !important;
        overflow-y: auto;
    }

    .chatbox .card,
    #chatmodel {
        min-height: 100vh !important;
    }

    .card-body.pt-2.ps-3.pr-3 tr {
        text-align: right !important;
    }

</style>