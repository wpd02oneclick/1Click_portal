<?php

namespace App\Http\Controllers;


class TestingController extends Controller
{
    //
    public function index()
    {

    }

}
