<?php

namespace App\Http\Livewire\PreVillages;

use Livewire\Component;

class AllEducation extends Component
{
    public function render()
    {
        return view('livewire.pre-villages.all-education');
    }
}
